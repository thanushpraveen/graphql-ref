const express = require("express");
const expressGraphQL = require("express-graphql");

const mongoose = require("mongoose");
const cors = require("cors");
const app = express();

// mongodb+srv://aequalisys:<password>@amp1.erder.mongodb.net/myFirstDatabase?retryWrites=true&w=majority
mongoose.connect(
  "mongodb+srv://aequalisys:admindev@amp1.erder.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
  {
    useUnifiedTopology: true,
    useNewUrlParser: true,
  }
);
const schema = require("./schema/schema");
mongoose.connection.once("open", () => {
  console.log("Yes, We got DB");
});
app.use(cors());
app.use(
  "/graphql",
  expressGraphQL.graphqlHTTP({
    schema,
    graphiql: true,
  })
);

app.listen(4000, () => {
  console.log(`PORT Listening at 4000`);
});
